const BASE_URL = "http://10.88.234.46:8080"

export default BASE_URL